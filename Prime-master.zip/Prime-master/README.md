# Prime
I have written a code to efficiently check for Prime number.
